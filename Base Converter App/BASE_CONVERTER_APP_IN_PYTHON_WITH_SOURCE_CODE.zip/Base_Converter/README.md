# Base_Converter
This python application is designed to convert from any number system to any number system and
it is also capable of handling all types of exceptions. It has the funtionality to have a simple 
built in calculator for small but powerful calculations with Reset and backspace buttons.
